//
//  SupportEntity.m
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import "SupportEntity.h"

@implementation SupportEntity

// Insert code here to add functionality to your managed object subclass

@end
