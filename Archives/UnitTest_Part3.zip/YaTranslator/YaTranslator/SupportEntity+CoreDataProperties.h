//
//  SupportEntity+CoreDataProperties.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "SupportEntity.h"

NS_ASSUME_NONNULL_BEGIN

@interface SupportEntity (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *inputCountryCode;
@property (nullable, nonatomic, retain) NSString *inputCountryName;
@property (nullable, nonatomic, retain) NSSet<NSManagedObject *> *countries;

@end

@interface SupportEntity (CoreDataGeneratedAccessors)

- (void)addCountriesObject:(NSManagedObject *)value;
- (void)removeCountriesObject:(NSManagedObject *)value;
- (void)addCountries:(NSSet<NSManagedObject *> *)values;
- (void)removeCountries:(NSSet<NSManagedObject *> *)values;

@end

NS_ASSUME_NONNULL_END
