//
//  YTYandexApiServiceDelegate.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import <Foundation/Foundation.h>

@class YTYandexApiService;
@class YTSupportLanguage;
@class YTTranslator;
@protocol YTYandexApiServiceDelegate <NSObject>
@optional
- (void) yandexApiService:(YTYandexApiService*)service didTranslate:(YTTranslator*)translator;

- (void) yandexApiService:(YTYandexApiService*)service didSupportLanguages:(NSArray<YTSupportLanguage*>*)supportLanguages;

- (void) yandexApiService:(YTYandexApiService*)service didFailWithError:(NSError*)error;
@end
