//
//  InputLanguageEntity+CoreDataProperties.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 14/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "InputLanguageEntity.h"
#import "TranslatorEntity.h"

NS_ASSUME_NONNULL_BEGIN

@interface InputLanguageEntity (CoreDataProperties)

@property (nullable, nonatomic, retain) TranslatorEntity *translator;

@end

NS_ASSUME_NONNULL_END
