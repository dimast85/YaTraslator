//
//  TranslatorEntity.m
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 14/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import "TranslatorEntity.h"
#import "InputLanguageEntity.h"
#import "OutputLanguageEntity.h"

@implementation TranslatorEntity

// Insert code here to add functionality to your managed object subclass

@end
