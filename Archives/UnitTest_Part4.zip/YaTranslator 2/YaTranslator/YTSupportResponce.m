//
//  YTSupportResponce.m
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import "YTSupportResponce.h"
#import "YTSupportLanguage.h"
#import "YTCoreDataService.h"
#import "YTGetLangs.h"

@implementation YTSupportResponce
-(void)parseServerDictionary:(NSDictionary *)serverDictionary {
    // Read
    NSArray *inputOutputCodes = serverDictionary[KeySupportLanguagesDirs];
    NSDictionary *langsDictionary = serverDictionary[KeySupportLanguagesLangs];
    
    YTGetLangs *getLangs = [YTGetLangs new];
    for (NSString *inputOutputCode in inputOutputCodes) {
        [getLangs addInputOutputCountryCode:inputOutputCode andLangsDictionary:langsDictionary];
    }
    
    // Save
    YTCoreDataService *cDataService = [YTCoreDataService new];
    [cDataService saveSupportLanguages:getLangs.supports];
    
    //
    if ([self.delegate respondsToSelector:@selector(yandexApiService:didSupportLanguages:)]) {
        [self.delegate yandexApiService:[YTYandexApiService new] didSupportLanguages:getLangs.supports];
    }
}
@end
