//
//  YTTranslateView.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 14/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YTTranslateView : UIView
@property (weak, nonatomic) IBOutlet UIButton *translateButton;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *clearButton;
@end
