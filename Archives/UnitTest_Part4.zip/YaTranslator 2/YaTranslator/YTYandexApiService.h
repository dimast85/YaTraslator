//
//  YTYandexApiService.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "YTYandexApiServiceDelegate.h"

extern NSString *const QueryTranslate;
extern NSString *const QuerySupport;

extern NSString *const ErrorText;

@interface YTYandexApiService : NSObject
/// Запрос
-(void)requestQuery:(NSString *)query andParams:(NSDictionary *)params andDelegate:(id<YTYandexApiServiceDelegate>)delegate;
@end
