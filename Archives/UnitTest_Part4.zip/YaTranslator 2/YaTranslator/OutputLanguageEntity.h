//
//  OutputLanguageEntity.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 14/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LanguageEntity.h"

NS_ASSUME_NONNULL_BEGIN

@interface OutputLanguageEntity : LanguageEntity

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "OutputLanguageEntity+CoreDataProperties.h"
