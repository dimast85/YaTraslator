//
//  YTYandexApiService.m
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import "YTYandexApiService.h"

NSString *const ErrorText = @"error_text";

@implementation YTYandexApiService

@end
