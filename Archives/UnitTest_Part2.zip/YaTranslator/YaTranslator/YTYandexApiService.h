//
//  YTYandexApiService.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const ErrorText;

@interface YTYandexApiService : NSObject

@end
