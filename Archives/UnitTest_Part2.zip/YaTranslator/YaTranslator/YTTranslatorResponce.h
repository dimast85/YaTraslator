//
//  YTTranslatorResponce.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 14/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import "YTResponce.h"

@interface YTTranslatorResponce : YTResponce

@end
