//
//  CountryEntity.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class SupportEntity;

NS_ASSUME_NONNULL_BEGIN

@interface CountryEntity : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "CountryEntity+CoreDataProperties.h"
