//
//  OutputLanguageEntity.m
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 14/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import "OutputLanguageEntity.h"

@implementation OutputLanguageEntity

// Insert code here to add functionality to your managed object subclass

@end
