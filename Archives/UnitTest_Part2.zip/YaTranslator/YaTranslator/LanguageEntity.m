//
//  LanguageEntity.m
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 14/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import "LanguageEntity.h"
#import "CountryEntity.h"

@implementation LanguageEntity

// Insert code here to add functionality to your managed object subclass

@end
