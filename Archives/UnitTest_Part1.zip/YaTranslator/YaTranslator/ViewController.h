//
//  ViewController.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 12/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

