//
//  YTCoreDataService.h
//  YaTranslator
//
//  Created by Мартынов Дмитрий on 13/07/2017.
//  Copyright © 2017 Мартынов Дмитрий. All rights reserved.
//

#import <Foundation/Foundation.h>

@class YTCountry;
@class YTSupportLanguage;
@interface YTCoreDataService : NSObject
/// Сохраняем список допустимых языков
-(void) saveSupportLanguages:(NSArray<YTSupportLanguage*>*)supports;

/// Получаем все исходные языки для перевода
- (NSArray<YTCountry*>*)getInputCountries;

/// Получаем все выходные языки для страны @param inputCountryCode Код языка (ru, en, fr и тд)
- (NSArray<YTCountry*>*)getOutputCountriesWithInputCountryCode:(NSString*)inputCountryCode;
@end
